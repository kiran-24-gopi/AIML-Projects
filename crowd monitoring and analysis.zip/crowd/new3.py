import cv2
import numpy as np
from scipy.spatial import distance as dist
import csv
from datetime import datetime
from time import time

# Adjusted parameters
MIN_CONF = 0.2
NMS_THRESH = 0.4
MIN_DISTANCE = 35

def detect_people(frame, net, ln, personIdx=0):
    (H, W) = frame.shape[:2]
    results = []

    # Preprocess frame for YOLO
    blob = cv2.dnn.blobFromImage(frame, 1 / 255.0, (416, 416), swapRB=True, crop=False)
    net.setInput(blob)
    layerOutputs = net.forward(ln)

    boxes = []
    centroids = []
    confidences = []

    for output in layerOutputs:
        for detection in output:
            scores = detection[5:]
            classID = np.argmax(scores)
            confidence = scores[classID]

            if classID == personIdx and confidence > MIN_CONF:
                box = detection[0:4] * np.array([W, H, W, H])
                (centerX, centerY, width, height) = box.astype("int")

                x = int(centerX - (width / 2))
                y = int(centerY - (height / 2))

                boxes.append([x, y, int(width), int(height)])
                centroids.append((centerX, centerY))
                confidences.append(float(confidence))

    idxs = cv2.dnn.NMSBoxes(boxes, confidences, MIN_CONF, NMS_THRESH)

    if len(idxs) > 0:
        for i in idxs.flatten():
            (x, y) = (boxes[i][0], boxes[i][1])
            (w, h) = (boxes[i][2], boxes[i][3])

            r = (confidences[i], (x, y, x + w, y + h), centroids[i])
            results.append(r)

    return results

# Load YOLO model
configPath = r"G:\Kiran\crowd\yolov3.cfg"
weightsPath = r"G:\Kiran\crowd\yolov3.weights"
net = cv2.dnn.readNetFromDarknet(configPath, weightsPath)
ln = net.getLayerNames()
ln = [ln[i - 1] for i in net.getUnconnectedOutLayers()]

# Capture video feeds
vs1 = cv2.VideoCapture("sample_footage_1.mp4")
vs2 = cv2.VideoCapture("sample_footage_2.mp4")

# CSV to log data
csv_file = open("people_count_data.csv", mode="w", newline="")
csv_writer = csv.writer(csv_file)
csv_writer.writerow(["Timestamp", "Video 1 People Count", "Video 2 People Count", "Crowded Areas 1", "Crowded Areas 2"])

# Track time for 15-second interval
start_time = time()
csv_update_interval = 15  # in seconds

while True:
    (grabbed1, frame1) = vs1.read()
    (grabbed2, frame2) = vs2.read()

    if not grabbed1 or not grabbed2:
        break

    frame1 = cv2.resize(frame1, (600, 600))
    frame2 = cv2.resize(frame2, (600, 600))

    results1 = detect_people(frame1, net, ln, personIdx=0)
    results2 = detect_people(frame2, net, ln, personIdx=0)

    person_count1 = len(results1)
    person_count2 = len(results2)

    # Crowded areas detection
    violate1, violate2 = set(), set()

    if person_count1 > 1:
        centroids1 = np.array([r[2] for r in results1])
        D1 = dist.cdist(centroids1, centroids1, metric="euclidean")

        for i in range(0, D1.shape[0]):
            for j in range(i + 1, D1.shape[1]):
                if D1[i, j] < MIN_DISTANCE:
                    violate1.add(i)
                    violate1.add(j)

    if person_count2 > 1:
        centroids2 = np.array([r[2] for r in results2])
        D2 = dist.cdist(centroids2, centroids2, metric="euclidean")

        for i in range(0, D2.shape[0]):
            for j in range(i + 1, D2.shape[1]):
                if D2[i, j] < MIN_DISTANCE:
                    violate2.add(i)
                    violate2.add(j)

    # Draw bounding boxes and counts
    for (i, (prob, bbox, centroid)) in enumerate(results1):
        (startX, startY, endX, endY) = bbox
        color = (0, 255, 0) if i not in violate1 else (0, 0, 255)
        cv2.rectangle(frame1, (startX, startY), (endX, endY), color, 2)

    for (i, (prob, bbox, centroid)) in enumerate(results2):
        (startX, startY, endX, endY) = bbox
        color = (0, 255, 0) if i not in violate2 else (0, 0, 255)
        cv2.rectangle(frame2, (startX, startY), (endX, endY), color, 2)

    # Display people count and crowd count on the frame
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    cv2.putText(frame1, f"{timestamp}", (10, frame1.shape[0] - 50), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    cv2.putText(frame1, f"People Count: {person_count1}", (10, frame1.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    cv2.putText(frame1, f"Crowded areas: {len(violate1)}", (10, frame1.shape[0] - 80), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

    cv2.putText(frame2, f"{timestamp}", (10, frame2.shape[0] - 50), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
    cv2.putText(frame2, f"People Count: {person_count2}", (10, frame2.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    cv2.putText(frame2, f"Crowded areas: {len(violate2)}", (10, frame2.shape[0] - 80), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

    # Update CSV every 15 seconds
    current_time = time()
    if current_time - start_time >= csv_update_interval:
        csv_writer.writerow([timestamp, person_count1, person_count2, len(violate1), len(violate2)])
        csv_file.flush()  # Ensure data is written immediately
        start_time = current_time  # Reset the timer

    # Combine and display frames
    combined_frame = np.hstack((frame1, frame2))
    cv2.imshow("Combined Frame", combined_frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

# Properly release resources
csv_file.close()
cv2.destroyAllWindows()
vs1.release()
vs2.release()
