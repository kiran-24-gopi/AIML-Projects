from scipy.spatial import distance as dist
import numpy as np
import imutils
import cv2
import csv
from datetime import datetime
from time import time

# Function to detect people using YOLO and draw bounding boxes
def detect_people(frame, net, ln, personIdx):
    (H, W) = frame.shape[:2]
    results = []
    blob = cv2.dnn.blobFromImage(frame, 1 / 255.0, (416, 416), swapRB=True, crop=False)
    net.setInput(blob)
    layerOutputs = net.forward(ln)

    boxes = []
    confidences = []
    centroids = []

    for output in layerOutputs:
        for detection in output:
            scores = detection[5:]
            classID = np.argmax(scores)
            confidence = scores[classID]

            if classID == personIdx and confidence > MIN_CONF:
                box = detection[0:4] * np.array([W, H, W, H])
                (centerX, centerY, width, height) = box.astype("int")
                x = int(centerX - (width / 2))
                y = int(centerY - (height / 2))

                boxes.append([x, y, int(width), int(height)])
                confidences.append(float(confidence))
                centroids.append((centerX, centerY))

    idxs = cv2.dnn.NMSBoxes(boxes, confidences, MIN_CONF, NMS_THRESH)

    if len(idxs) > 0:
        for i in idxs.flatten():
            (x, y) = (boxes[i][0], boxes[i][1])
            (w, h) = (boxes[i][2], boxes[i][3])
            centroid = centroids[i]

            # Store the detected person’s info (confidence, bounding box, centroid)
            results.append((confidences[i], (x, y, x + w, y + h), centroid))

    return results


MIN_CONF = 0.3
NMS_THRESH = 0.3
MIN_DISTANCE = 30

# Load YOLO model
configPath = r"G:\Kiran\crowd\yolov3.cfg"
weightsPath = r"G:\Kiran\crowd\yolov3.weights"
net = cv2.dnn.readNetFromDarknet(configPath, weightsPath)
ln = net.getLayerNames()
output_layer_indices = [net.getLayerId(name) - 1 for name in ln]

# Capture two different video streams
vs1 = cv2.VideoCapture("sample_footage_1.mp4")
vs2 = cv2.VideoCapture("sample_footage_2.mp4")

# Create and open a CSV file to store people count data
with open("people_count_data.csv", mode="w", newline="") as csv_file:
    csv_writer = csv.writer(csv_file)
    
    # Write header row
    csv_writer.writerow(["Timestamp", "Video 1 People Count", "Video 2 People Count", "Crowded Areas 1", "Crowded Areas 2"])
    
    start_time = time()

    while True:
        # Read frames from both video streams
        (grabbed1, frame1) = vs1.read()
        (grabbed2, frame2) = vs2.read()

        # Break if either video ends
        if not grabbed1 or not grabbed2:
            break

        # Resize frames to 800 width
        frame1 = imutils.resize(frame1, width=800)
        frame2 = imutils.resize(frame2, width=800)

        # Detect people in both frames
        results1 = detect_people(frame1, net, output_layer_indices, personIdx=0)
        results2 = detect_people(frame2, net, output_layer_indices, personIdx=0)

        # Initialize variables for violations
        violate1 = set()
        violate2 = set()
        person_count1 = len(results1)
        person_count2 = len(results2)

        # Process first frame
        if len(results1) >= 2:
            centroids1 = np.array([r[2] for r in results1])
            D1 = dist.cdist(centroids1, centroids1, metric="euclidean")

            for i in range(0, D1.shape[0]):
                for j in range(i + 1, D1.shape[1]):
                    if D1[i, j] < MIN_DISTANCE:
                        violate1.add(i)
                        violate1.add(j)

        # Process second frame
        if len(results2) >= 2:
            centroids2 = np.array([r[2] for r in results2])
            D2 = dist.cdist(centroids2, centroids2, metric="euclidean")

            for i in range(0, D2.shape[0]):
                for j in range(i + 1, D2.shape[1]):
                    if D2[i, j] < MIN_DISTANCE:
                        violate2.add(i)
                        violate2.add(j)

        # Get current time and date
        now = datetime.now()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")

        # Draw bounding boxes for the first video
        for (i, (conf, bbox, centroid)) in enumerate(results1):
            (startX, startY, endX, endY) = bbox
            color = (0, 255, 0) if i not in violate1 else (0, 0, 255)  # Green if not violating, Red if violating
            cv2.rectangle(frame1, (startX, startY), (endX, endY), color, 2)
            cv2.circle(frame1, centroid, 5, (0, 0, 255), 1)

        # Draw bounding boxes for the second video
        for (i, (conf, bbox, centroid)) in enumerate(results2):
            (startX, startY, endX, endY) = bbox
            color = (0, 255, 0) if i not in violate2 else (0, 0, 255)  # Green if not violating, Red if violating
            cv2.rectangle(frame2, (startX, startY), (endX, endY), color, 2)
            cv2.circle(frame2, centroid, 5, (0, 0, 255), 1)

        # Display info on first frame
        text1 = f"People Count: {person_count1}"
        violation_text1 = f"Crowded areas: {len(violate1) // 2}"
        cv2.putText(frame1, text1, (10, frame1.shape[0] - 60), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (255, 255, 0), 2)
        cv2.putText(frame1, violation_text1, (10, frame1.shape[0] - 25), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (0, 0, 255), 3)
        cv2.putText(frame1, current_time, (10, frame1.shape[0] - 90), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (255, 255, 255), 2)

        # Display info on second frame
        text2 = f"People Count: {person_count2}"
        violation_text2 = f"Crowded areas: {len(violate2) // 2}"
        cv2.putText(frame2, text2, (10, frame2.shape[0] - 60), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (255, 255, 0), 2)
        cv2.putText(frame2, violation_text2, (10, frame2.shape[0] - 25), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (0, 0, 255), 3)
        cv2.putText(frame2, current_time, (10, frame2.shape[0] - 90), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (255, 255, 255), 2)

        # Stack the two frames horizontally
        combined_frame = np.hstack((frame1, frame2))

        # Display the combined frame
        cv2.imshow("Combined Frame", combined_frame)
        key = cv2.waitKey(1) & 0xFF

        # Every 15 seconds, store the data in the CSV file
        elapsed_time = time() - start_time
        if elapsed_time >= 15:  # Store data every 15 seconds
            csv_writer.writerow([current_time, person_count1, person_count2, len(violate1) // 2, len(violate2) // 2])
            csv_file.flush()  # Ensure data is written to file immediately
            start_time = time()  # Reset the timer

        # Quit if 'q' is pressed
        if key == ord("q"):
            break

# Release video streams and close any open windows
vs1.release()
vs2.release()
cv2.destroyAllWindows()
