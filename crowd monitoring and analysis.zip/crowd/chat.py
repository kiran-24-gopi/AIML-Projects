import numpy as np
import cv2
import imutils
from scipy.spatial import distance as dist
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import joblib
import pandas as pd
from datetime import datetime

# YOLO Configuration
MIN_CONF = 0.3
NMS_THRESH = 0.3
MIN_DISTANCE = 40
configPath = r"G:\Kiran\crowd\yolov3.cfg"
weightsPath = r"G:\Kiran\crowd\yolov3.weights"

# Load YOLO Model
net = cv2.dnn.readNetFromDarknet(configPath, weightsPath)
ln = net.getLayerNames()
output_layer_indices = [net.getLayerId(name) - 1 for name in ln]

# Load Random Forest Model (train if not available)
model_path = 'random_forest_model.pkl'
try:
    model = joblib.load(model_path)
    print("Random Forest model loaded.")
except FileNotFoundError:
    print("No pre-trained model found. Training a new model...")
    
    # Example CSV data format: [Hour, DayOfWeek, Weather, Special_Event, Crowd_Count]
    df = pd.read_csv('crowd_data.csv')
    X = df[["Hour", "DayOfWeek", "Weather", "Special_Event"]]
    y = df["Crowd_Count"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    joblib.dump(model, model_path)
    print("Random Forest model trained.")

# Function to detect people using YOLO
def detect_people(frame, net, ln, personIdx):
    (H, W) = frame.shape[:2]
    results = []
    blob = cv2.dnn.blobFromImage(frame, 1 / 255.0, (416, 416), swapRB=True, crop=False)
    net.setInput(blob)
    layerOutputs = net.forward(ln)

    boxes, confidences, centroids = [], [], []
    for output in layerOutputs:
        for detection in output:
            scores = detection[5:]
            classID = np.argmax(scores)
            confidence = scores[classID]

            if classID == personIdx and confidence > MIN_CONF:
                box = detection[0:4] * np.array([W, H, W, H])
                (centerX, centerY, width, height) = box.astype("int")
                x = int(centerX - (width / 2))
                y = int(centerY - (height / 2))

                boxes.append([x, y, int(width), int(height)])
                confidences.append(float(confidence))
                centroids.append((centerX, centerY))

    idxs = cv2.dnn.NMSBoxes(boxes, confidences, MIN_CONF, NMS_THRESH)
    if len(idxs) > 0:
        for i in idxs.flatten():
            (x, y) = (boxes[i][0], boxes[i][1])
            (w, h) = (boxes[i][2], boxes[i][3])
            centroid = centroids[i]
            results.append((confidences[i], (x, y, x + w, y + h), centroid))

    return results

# Function to predict crowd size using Random Forest
def predict_crowd_size(hour, day_of_week, weather, special_event, model):
    # Prepare input for the Random Forest model
    input_data = pd.DataFrame([[hour, day_of_week, weather, special_event]],
                              columns=["Hour", "DayOfWeek", "Weather", "Special_Event"])
    prediction = model.predict(input_data)
    return int(prediction[0])

# Initialize video capture and process frames
vs = cv2.VideoCapture("crowd_monitoring_sample_video.mp4")
while True:
    (grabbed, frame) = vs.read()
    if not grabbed:
        break

    frame = imutils.resize(frame, width=900)
    results = detect_people(frame, net, output_layer_indices, personIdx=0)
    violate = set()

    if len(results) >= 2:
        centroids = np.array([r[2] for r in results])
        D = dist.cdist(centroids, centroids, metric="euclidean")

        for i in range(0, D.shape[0]):
            for j in range(i + 1, D.shape[1]):
                if D[i, j] < MIN_DISTANCE:
                    violate.add(i)
                    violate.add(j)

    for (i, (prob, bbox, centroid)) in enumerate(results):
        (startX, startY, endX, endY) = bbox
        (cX, cY) = centroid
        color = (0, 255, 0)
        if i in violate:
            color = (0, 0, 255)
        cv2.rectangle(frame, (startX, startY), (endX, endY), color, 2)
        cv2.circle(frame, (int(cX), int(cY)), 5, color, 1)

    text = f"Crowded areas identified: {len(violate)}"
    cv2.putText(frame, text, (10, frame.shape[0] - 25), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (0, 0, 255), 3)

    # Extract current time and predict future crowd size
    current_time = datetime.now()
    hour = current_time.hour
    day_of_week = current_time.weekday()

    weather = 0  # Replace with actual weather data
    special_event = 0  # Replace with actual special event data
    
    predicted_crowd_size = predict_crowd_size(hour, day_of_week, weather, special_event, model)
    prediction_text = f"Predicted Crowd Size: {predicted_crowd_size}"
    cv2.putText(frame, prediction_text, (10, frame.shape[0] - 50), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (0, 255, 0), 3)

    cv2.imshow("Frame", frame)
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break

vs.release()
cv2.destroyAllWindows()
