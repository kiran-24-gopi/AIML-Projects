import cv2
import numpy as np
from scipy.spatial import distance as dist
import imutils
import datetime
import gspread
from oauth2client.service_account import ServiceAccountCredentials

# Function to detect people using YOLO
def detect_people(frame, net, ln, personIdx):
    # Extract dimensions of the frame
    (H, W) = frame.shape[:2]
    results = []

    # Construct a blob from the input frame and perform a forward pass of the YOLO object detector
    blob = cv2.dnn.blobFromImage(frame, 1 / 255.0, (416, 416), swapRB=True, crop=False)
    net.setInput(blob)
    layerOutputs = net.forward(ln)

    # Initialize lists to store bounding boxes, confidences, and centroids
    boxes = []
    confidences = []
    centroids = []

    # Loop over each layer output
    for output in layerOutputs:
        # Loop over each detection in the output
        for detection in output:
            # Extract class ID and confidence of the current detection
            scores = detection[5:]
            classID = np.argmax(scores)
            confidence = scores[classID]

            # Filter detections to only consider 'person' class and above minimum confidence
            if classID == personIdx and confidence > MIN_CONF:
                # Scale bounding box coordinates to match the size of the frame
                box = detection[0:4] * np.array([W, H, W, H])
                (centerX, centerY, width, height) = box.astype("int")

                # Calculate top-left corner coordinates of the bounding box
                x = int(centerX - (width / 2))
                y = int(centerY - (height / 2))

                # Update lists
                boxes.append([x, y, int(width), int(height)])
                confidences.append(float(confidence))
                centroids.append((centerX, centerY))

    # Apply non-maxima suppression to suppress weak, overlapping bounding boxes
    idxs = cv2.dnn.NMSBoxes(boxes, confidences, MIN_CONF, NMS_THRESH)

    # Ensure at least one detection exists
    if len(idxs) > 0:
        # Loop over the indexes
        for i in idxs.flatten():
            # Extract bounding box coordinates and centroid
            (x, y) = (boxes[i][0], boxes[i][1])
            (w, h) = (boxes[i][2], boxes[i][3])
            centroid = centroids[i]

            # Update results with confidence, bounding box, and centroid
            results.append((confidences[i], (x, y, x + w, y + h), centroid))

    return results

# Initialize minimum probability to filter weak detections along with
# the threshold when applying non-maxima suppression
MIN_CONF = 0.3
NMS_THRESH = 0.3

# Define the minimum safe distance (in pixels) that two people can be
# from each other
MIN_DISTANCE = 40

# Absolute paths to configuration and weights files
configPath = r"E:\Python\crowd\yolov3.cfg"
weightsPath = r"E:\Python\crowd\yolov3.weights"

# Load the YOLO model
net = cv2.dnn.readNetFromDarknet(configPath, weightsPath)

# Get the output layer names
ln = net.getLayerNames()
output_layer_indices = [net.getLayerId(name) - 1 for name in ln]

# Authorize Google Sheets API
scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('credentials.json', scope)
client = gspread.authorize(creds)

# Function to store crowd count in Google Sheets
def store_crowd_count(count):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    sheet = client.open('Crowd Count Sheet').sheet1
    sheet.append_row([timestamp, count])

# Initialize video capture
vs = cv2.VideoCapture("crowd_monitoring_sample.mp4")

# Initialize frame with a placeholder value
frame = None

while True:
    (grabbed, frame) = vs.read()
    if not grabbed:
        break

    # Resize the frame
    frame = imutils.resize(frame, width=900)

    # Detect people (and only people) in the frame
    results = detect_people(frame, net, output_layer_indices, personIdx=0)

    # Initialize the set of indexes that violate the minimum social distance
    violate = set()

    # Ensure there are at least two people detections (required to compute pairwise distance maps)
    if len(results) >= 2:
        centroids = np.array([r[2] for r in results])
        D = dist.cdist(centroids, centroids, metric="euclidean")

        # Loop over the upper triangular of the distance matrix
        for i in range(0, D.shape[0]):
            for j in range(i + 1, D.shape[1]):
                if D[i, j] < MIN_DISTANCE:
                    violate.add(i)
                    violate.add(j)

    # Store crowd count in Google Sheets
    store_crowd_count(int(len(violate) / 2))

    # Loop over the results and draw rectangles and circles
    for (i, (prob, bbox, centroid)) in enumerate(results):
        (startX, startY, endX, endY) = bbox
        (cX, cY) = centroid
        color = (0, 255, 0)

        if i in violate:
            color = (0, 0, 255)

        cv2.rectangle(frame, (startX, startY), (endX, endY), color, 2)
        cv2.circle(frame, (int(cX), int(cY)), 5, color, 1)

    text = "Crowded areas identified till now: {}".format(int(len(violate) / 2))
    cv2.putText(frame, text, (10, frame.shape[0] - 25), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (0, 0, 255), 3)
    cv2.imshow("Frame", frame)
    key = cv2.waitKey(1) & 0xFF

    if key == ord("q"):
        break

# Release the video stream
vs.release()
cv2.destroyAllWindows()
