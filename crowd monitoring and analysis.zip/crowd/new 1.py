from scipy.spatial import distance as dist
import numpy as np
import imutils
import cv2

# Function to detect people using YOLO
def detect_people(frame, net, ln, personIdx):
    (H, W) = frame.shape[:2]
    results = []
    blob = cv2.dnn.blobFromImage(frame, 1 / 255.0, (416, 416), swapRB=True, crop=False)
    net.setInput(blob)
    layerOutputs = net.forward(ln)

    boxes = []
    confidences = []
    centroids = []

    for output in layerOutputs:
        for detection in output:
            scores = detection[5:]
            classID = np.argmax(scores)
            confidence = scores[classID]

            if classID == personIdx and confidence > MIN_CONF:
                box = detection[0:4] * np.array([W, H, W, H])
                (centerX, centerY, width, height) = box.astype("int")
                x = int(centerX - (width / 2))
                y = int(centerY - (height / 2))

                boxes.append([x, y, int(width), int(height)])
                confidences.append(float(confidence))
                centroids.append((centerX, centerY))

    idxs = cv2.dnn.NMSBoxes(boxes, confidences, MIN_CONF, NMS_THRESH)

    if len(idxs) > 0:
        for i in idxs.flatten():
            (x, y) = (boxes[i][0], boxes[i][1])
            (w, h) = (boxes[i][2], boxes[i][3])
            centroid = centroids[i]
            results.append((confidences[i], (x, y, x + w, y + h), centroid))

    return results


MIN_CONF = 0.3
NMS_THRESH = 0.3
MIN_DISTANCE = 40

configPath = r"G:\Kiran\crowd\yolov3.cfg"
weightsPath = r"G:\Kiran\crowd\yolov3.weights"
net = cv2.dnn.readNetFromDarknet(configPath, weightsPath)
ln = net.getLayerNames()
output_layer_indices = [net.getLayerId(name) - 1 for name in ln]

vs = cv2.VideoCapture("crowd_monitoring_sample_video.mp4")
frame = None

while True:
    (grabbed, frame) = vs.read()
    if not grabbed:
        break

    frame = imutils.resize(frame, width=900)
    results = detect_people(frame, net, output_layer_indices, personIdx=0)

    violate = set()
    person_count = len(results)  # Count the number of people detected

    if len(results) >= 2:
        centroids = np.array([r[2] for r in results])
        D = dist.cdist(centroids, centroids, metric="euclidean")

        for i in range(0, D.shape[0]):
            for j in range(i + 1, D.shape[1]):
                if D[i, j] < MIN_DISTANCE:
                    violate.add(i)
                    violate.add(j)

    for (i, (prob, bbox, centroid)) in enumerate(results):
        (startX, startY, endX, endY) = bbox
        (cX, cY) = centroid
        color = (0, 255, 0)

        if i in violate:
            color = (0, 0, 255)

        cv2.rectangle(frame, (startX, startY), (endX, endY), color, 2)
        cv2.circle(frame, (int(cX), int(cY)), 5, color, 1)

    # Display the number of people detected in the frame
    text = f"People Count: {person_count}"
    cv2.putText(frame, text, (10, frame.shape[0] - 60), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (255, 255, 0), 2)

    # Display the number of violations (crowded areas)
    violation_text = "Crowded areas: {}".format(len(violate) // 2)
    cv2.putText(frame, violation_text, (10, frame.shape[0] - 25), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (0, 0, 255), 3)

    cv2.imshow("Frame", frame)
    key = cv2.waitKey(1) & 0xFF

    if key == ord("q"):
        break

vs.release()
cv2.destroyAllWindows()
