import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import joblib

# Load your crowd data
crowd_data = pd.read_csv('crowd_data.csv', header=None, names=["Time", "Crowd_Count", "Weather", "Special_Event"])

# Prepare features and target variable
crowd_data['Time'] = pd.to_datetime(crowd_data['Time'])
crowd_data['Hour'] = crowd_data['Time'].dt.hour
crowd_data['DayOfWeek'] = crowd_data['Time'].dt.dayofweek

X = crowd_data[["Hour", "DayOfWeek", "Weather", "Special_Event"]]
y = crowd_data["Crowd_Count"]

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train the Random Forest model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Save the model
joblib.dump(model, 'random_forest_model.pkl')
